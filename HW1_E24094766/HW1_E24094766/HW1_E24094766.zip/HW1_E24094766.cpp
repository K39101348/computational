﻿#include<iostream> 
using namespace std;
int main()
{
	cout << "＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊" << endl;
	cout << "＊Name： WEI-LU LIN 　　　　　  ＊" << endl;
	cout << "＊E-mail：K39101348＠gmail.com  ＊" << endl;
	cout << "＊Birthday：July 27th　 　　　  ＊" << endl;
	cout << "＊Height：183cm　　　　　　 　  ＊" << endl;
	cout << "＊ｗeight：64kg                 ＊" << endl;
	cout << "＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊" << endl;
	return 0;
}